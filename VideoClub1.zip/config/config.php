<?php
define('DBHOST', 'localhost');
define('DBPORT', 3306);
define('DBNAME', 'video');
define('DBUSER', 'root');
define('DBPWD', 'root');
?>